﻿using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System.Collections.Generic;
using Cours_DeRachid.Models;
using System.IO;
using System.Net;

namespace Cours_DeRachid.Controllers
{
    public class VilleController : Controller
    {
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "8g71zZg6AivLuFnUhFW9TuM55J2KPQcpD63A0tBO",
            BasePath = "https://mspgroup2-a447a-default-rtdb.europe-west1.firebasedatabase.app"
        };

        IFirebaseClient? Client;
        public ActionResult Index()
        {
            Client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = Client.Get("Ville");
            dynamic? data = JsonConvert.DeserializeObject<dynamic>(response.Body);
            var list = new List<Ville>();
            if (data != null)
            {
                foreach (var item in data)
                {
                    list.Add(JsonConvert.DeserializeObject<Ville>(((JProperty)item).Value.ToString()));
                }
            }
            return View(list);
        }

        public ActionResult Details(string id)
        {
            Client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = Client.Get("Ville/" + id);
            Ville? vil = JsonConvert.DeserializeObject<Ville>(response.Body);

            var list = new List<Vols>();
            FirebaseResponse res = Client.Get("Vols");
            dynamic? data1 = JsonConvert.DeserializeObject<dynamic>(res.Body);

            if (data1 != null)
            {
                foreach (var item in data1)
                {
                    Vols vol = JsonConvert.DeserializeObject<Vols>(((JProperty)item).Value.ToString());

                    if (vol.VilleDepart == vil.Nom || vol.VilleArrivee == vil.Nom)
                    {
                        list.Add(vol);
                    }
                }
            }

            vil.Vols = list;
            return View(vil);
        }


        public ActionResult Create()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Ville vil)
        {
            try
            {
                Client = new FireSharp.FirebaseClient(config);
                PushResponse response = Client.Push("Ville/", vil);
                vil.IdVille = response.Result.name;
                SetResponse setresponse = Client.Set("Ville/" + vil.IdVille, vil);

                if (setresponse.StatusCode == System.Net.HttpStatusCode.OK)
                    ModelState.AddModelError(string.Empty, "OK");
                else
                    ModelState.AddModelError(string.Empty, "KO!");

                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        public ActionResult Edit(string id)
        {
            Client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = Client.Get("Ville/" + id);
            Ville vil = JsonConvert.DeserializeObject<Ville>(response.Body);
            return View(vil);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Ville vil)
        {
            Client = new FireSharp.FirebaseClient(config);
            SetResponse response = Client.Set("Ville/" + vil.IdVille, vil);
            return RedirectToAction("Index");
        }

        public ActionResult Delete(string id)
        {
            Client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = Client.Get("Ville/" + id);
            Ville vil = JsonConvert.DeserializeObject<Ville>(response.Body);
            return View(vil);
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(string id, Ville vil)
        {
            Client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = Client.Delete("Ville/" + id);
            return RedirectToAction("Index");
        }
        private List<Vols> GetListVols()
        {
            var list = new List<Vols>();

            Client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = Client.Get("Vols");
            dynamic? data = JsonConvert.DeserializeObject<dynamic>(response.Body);

            if (data != null)
            {
                foreach (var item in data)
                {
                    list.Add(JsonConvert.DeserializeObject<Vols>(((JProperty)item).Value.ToString()));
                }
            }
            return list.Where(v => v.IdVille == data.IdVille).ToList();
        }
    }
}
