﻿using Cours_DeRachid.Models;
using FireSharp.Config;
using FireSharp.Interfaces;
using FireSharp.Response;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.Rendering;
using Newtonsoft.Json.Linq;
using Newtonsoft.Json;

namespace Cours_DeRachid.Controllers
{
    public class VolsController : Controller
    {

        //Interface de manipulation de la BDD FireBase
        IFirebaseConfig config = new FirebaseConfig
        {
            AuthSecret = "NIfXIeO34EqUngTDDtBu25h6osPxsId3W7Hkw3GD",
            BasePath = "https://nosql-3be02-default-rtdb.europe-west1.firebasedatabase.app"


        };
        IFirebaseClient? client;



        // GET: LivresController
        public ActionResult Index()
        {
            client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = client.Get("Vols");
            dynamic? data = JsonConvert.DeserializeObject<dynamic>(response.Body);
            var list = new List<Vols>();
            if (data != null)
            {
                foreach (var item in data)
                {
                    list.Add(JsonConvert.DeserializeObject<Vols>(((JProperty)item).Value.ToString()));
                }
            }
            return View(list);
        }

        // GET: LivresController/Details/5
        public ActionResult Details(string id)
        {
            client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = client.Get("Vols/" + id);
            Vols? aut = JsonConvert.DeserializeObject<Vols>(response.Body);
            return View(aut);
        }

        // GET: LivresController/Create
        public ActionResult Create()
        {
            ViewData["IdAuteur"] = new SelectList(GetListAuteurs(), "IdVille", "Nom");
            return View();
        }

        // POST: LivresController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Create(Vols liv)
        {
            try
            {
                client = new FireSharp.FirebaseClient(config);
                PushResponse response = client.Push("Vols/", liv);
                liv.IdVille = response.Result.name;
                SetResponse setResponse = client.Set("Vols/" + liv.IdVille, liv);

                if (setResponse.StatusCode == System.Net.HttpStatusCode.OK)
                    ModelState.AddModelError(string.Empty, "OK");
                else
                    ModelState.AddModelError(string.Empty, "KO!!");
            }
            catch (Exception ex)
            {

                ModelState.AddModelError(string.Empty, ex.Message);
            }

            return RedirectToAction("Index");
        }

        // GET: LivresController/Edit/5
        public ActionResult Edit(string id)
        {
            client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = client.Get("Vols/" + id);
            Vols aut = JsonConvert.DeserializeObject<Vols>(response.Body);
            return View(aut);
        }

        // POST: LivresController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Edit(Vols liv)
        {
            client = new FireSharp.FirebaseClient(config);
            SetResponse response = client.Set("Vols/" + liv.IdVille, liv);
            return RedirectToAction("Index");
        }

        // GET: LivresController/Delete/5
        public ActionResult Delete(string id)
        {
            client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = client.Get("Vols/" + id);
            Vols aut = JsonConvert.DeserializeObject<Vols>(response.Body);
            return View(aut);
        }

        // POST: LivresController/Delete/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult Delete(string id, Vols liv)
        {
            client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = client.Delete("Vols/" + id);
            return RedirectToAction("Index");
        }


        /// <summary>
        /// Récupérere la liste des auteurs
        /// </summary>
        /// <returns></returns>
        private List<Ville> GetListAuteurs()
        {
            var list = new List<Ville>();

            client = new FireSharp.FirebaseClient(config);
            FirebaseResponse response = client.Get("Ville");
            dynamic? data = JsonConvert.DeserializeObject<dynamic>(response.Body);

            if (data != null)
            {
                foreach (var item in data)
                {
                    list.Add(JsonConvert.DeserializeObject<Ville>(((JProperty)item).Value.ToString()));
                }
            }
            return list;
        }
    }
}
