﻿namespace Cours_DeRachid.Models
{
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    public class Vols
    {
        public string? IdVille { get; set; }

        public string? Ref { get; set; }

        public DateTime? Date_depart { get; set; }

        public DateTime? Date_arrivee { get; set; }

        public string? VilleDepart { get; set; }

        public string? VilleArrivee { get; set; }

    }
}