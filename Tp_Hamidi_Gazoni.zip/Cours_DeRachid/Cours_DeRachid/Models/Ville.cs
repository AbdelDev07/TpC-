﻿namespace Cours_DeRachid.Models
{
    using Newtonsoft.Json.Linq;
    using System;
    using System.Collections.Generic;
    public class Ville
    {
        public string? IdVille { get; set; }

        public string? Nom { get; set; }

        public virtual ICollection<Vols>? Vols { get; set; }


        public static explicit operator JProperty(Ville v)
        {
            throw new NotImplementedException();
        }
    }
}
